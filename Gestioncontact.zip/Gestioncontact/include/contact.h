
class contact
{
    public:
        contact();

    protected:

    private:
};
