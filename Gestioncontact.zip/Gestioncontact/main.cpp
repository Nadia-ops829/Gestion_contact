#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
#include <vector>
#include <locale>
#include <sstream>


using namespace std;


 void afficherMenu() {
    cout << "=== Biblioth�que de Gestion de Contacts ===" << endl;
    cout << "1. Afficher la liste des contacts" << endl;
    cout << "2. Ajouter un nouveau contact" << endl;
    cout << "3. Rechercher un contact par nom" << endl;
    cout << "4. Supprimer un contact de la liste" << endl;
    cout << "5.Trier les contacts par nom" <<endl;
    cout << "6. Quitter le programme" << endl;
    cout << "Veuillez choisir une�option�:�";
}

void verifierOuCreerFichier(const string& nomFichier) {
    // V�rifie si le fichier existe, sinon le cr�e
    ifstream fichierLecture(nomFichier);
    if (!fichierLecture) {
        ofstream fichierEcriture(nomFichier); // Cr�e un fichier vide
        if (fichierEcriture) {
            cout << "Le fichier des contacts n'existait pas. Il a �t� cr�� avec succ�s." << endl;
        } else {
            cout << "Erreur : Impossible de cr�er le fichier des contacts." << endl;
        }
    }
    fichierLecture.close();
}

void afficherListeContacts(const string& nomFichier) {
    ifstream fichier(nomFichier);

    if (!fichier) {
        cout << "Erreur : Le fichier des contacts est introuvable." << endl;
        return;
    }

    string ligne;
    bool fichierVide = true;

    cout << "=== Liste des contacts ===" << endl;

    while (getline(fichier, ligne)) {
        fichierVide = false;
        cout << ligne << endl;
    }

    if (fichierVide) {
        cout << "Le fichier est pr�sent mais ne contient aucun contact." << endl;
    }

    fichier.close();
}
void ajouterContact(const string& nomFichier) {
    ofstream fichier(nomFichier, ios::app); // Ouverture en mode ajout (append)
    if (!fichier) {
        cout << "Erreur : Impossible d'ouvrir le fichier des contacts pour l'�criture." << endl;
        return;
    }

    string nom, numero, email, adresse;

    cout << "=== Ajouter un nouveau contact ===" << endl;
    cout << "Nom : ";
    cin.ignore(); // Nettoyer le tampon d'entr�e avant getline
    getline(cin, nom);
    cout << "Num�ro de t�l�phone : ";
    getline(cin, numero);
    cout << "Email : ";
    getline(cin, email);
    cout << "Adresse : ";
    getline(cin, adresse);

    // �criture du contact dans le fichier
    fichier << "Nom: " << nom << ", T�l�phone: " << numero
            << ", Email: " << email << ", Adresse: " << adresse << endl;

    cout << "Contact ajout� avec succ�s !" << endl;

    fichier.close();
}
void rechercherContact(const string& nomFichier) {
    ifstream fichier(nomFichier);

    if (!fichier) {
        cout << "Erreur : Le fichier des contacts est introuvable." << endl;
        return;
    }

    cout << "=== Rechercher un contact ===" << endl;
    string nomRecherche;
    cout << "Entrez le nom � rechercher : ";
    cin.ignore();
    getline(cin, nomRecherche);

    string ligne;
    bool contactTrouve = false;

    // Recherche du nom dans chaque ligne
    while (getline(fichier, ligne)) {
        // Convertir les deux cha�nes en minuscules pour une recherche insensible � la casse
        string ligneMin = ligne, nomRechercheMin = nomRecherche;
        transform(ligneMin.begin(), ligneMin.end(), ligneMin.begin(), ::tolower);
        transform(nomRechercheMin.begin(), nomRechercheMin.end(), nomRechercheMin.begin(), ::tolower);

        if (ligneMin.find("nom: " + nomRechercheMin) != string::npos) {
            cout << "Contact trouv� : " << ligne << endl;
            contactTrouve = true;
        }
    }

    if (!contactTrouve) {
        cout << "Aucun contact correspondant � \"" << nomRecherche << "\" n'a �t� trouv�." << endl;
    }

    fichier.close();


}

void supprimerContact(const string& nomFichier) {
    ifstream fichierLecture(nomFichier);

    if (!fichierLecture) {
        cout << "Erreur : Le fichier des contacts est introuvable." << endl;
        return;
    }

    cout << "=== Supprimer un contact ===" << endl;
    string nomRecherche;
    cout << "Entrez le nom du contact � supprimer : ";
    cin.ignore();
    getline(cin, nomRecherche);

    vector<string> lignes;
    string ligne;
    bool contactTrouve = false;

    // Charger toutes les lignes dans un vecteur sauf celle � supprimer
    while (getline(fichierLecture, ligne)) {
        string ligneMin = ligne, nomRechercheMin = nomRecherche;
        transform(ligneMin.begin(), ligneMin.end(), ligneMin.begin(), ::tolower);
        transform(nomRechercheMin.begin(), nomRechercheMin.end(), nomRechercheMin.begin(), ::tolower);

        if (ligneMin.find("nom: " + nomRechercheMin) != string::npos) {
            contactTrouve = true;
            cout << "Contact supprim� : " << ligne << endl;
        } else {
            lignes.push_back(ligne); // Ajouter les autres lignes
        }
    }

    fichierLecture.close();

    if (!contactTrouve) {
        cout << "Aucun contact correspondant � \"" << nomRecherche << "\" n'a �t� trouv�." << endl;
        return;
    }

    // R��crire les contacts restants dans le fichier
    ofstream fichierEcriture(nomFichier, ios::trunc);
    if (!fichierEcriture) {
        cout << "Erreur : Impossible d'�crire dans le fichier des contacts." << endl;
        return;
    }

    for (const string& ligne : lignes) {
        fichierEcriture << ligne << endl;
    }

    fichierEcriture.close();
    cout << "Mise � jour du fichier effectu�e avec succ�s !" << endl;
}



void trierContacts(const string& nomFichier) {
    ifstream fichier(nomFichier);

    if (!fichier) {
        cout << "Erreur : Le fichier des contacts est introuvable." << endl;
        return;
    }

    vector<string> contacts;
    string ligne;

    // Lire tous les contacts depuis le fichier
    while (getline(fichier, ligne)) {
        contacts.push_back(ligne);
    }
    fichier.close();

    if (contacts.empty()) {
        cout << "Aucun contact � trier." << endl;
        return;
    }

    // Trier les contacts par ordre alphab�tique
    sort(contacts.begin(), contacts.end(), [](const string& a, const string& b) {
        string nomA = a.substr(a.find("Nom: ") + 5);
        string nomB = b.substr(b.find("Nom: ") + 5);
        return nomA < nomB;
    });

    // Afficher les contacts tri�s
    cout << "=== Contacts tri�s par ordre alphab�tique ===" << endl;
    for (const auto& contact : contacts) {
        cout << contact << endl;
    }
}





int main()
{
    setlocale(LC_ALL, "");
    int choix;
    bool quitter = false;
    const string nomFichier = "contacts.txt"; // Nom du fichier contenant�les�contacts

    verifierOuCreerFichier(nomFichier);

   while (!quitter) {
        afficherMenu();
        cin >> choix;

        switch (choix) {
            case 1:
                afficherListeContacts(nomFichier);
                break;
            case 2:
                ajouterContact(nomFichier);
                break;
            case 3:
                rechercherContact(nomFichier);
                break;
            case 4:
                supprimerContact(nomFichier);
                break;
            case 5:
                trierContacts(nomFichier);
                break;
            case 6:
                cout << "Merci d'avoir utilis� le programme. Au revoir !" << endl;
                quitter = true;
                break;
            default:
                cout << "Option invalide. Veuillez choisir une option entre 1 et 5." << endl;
        }

        cout << endl; // Ajout d'une ligne vide pour une meilleure lisibilit�.


   }

    return 0;
}
