#include "contact.h"

contact::contact()
{
    //ctor
}
